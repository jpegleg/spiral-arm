#!/usr/bin/env bash
rm -f /opt/spiral-arm/blacklist
touch /opt/spiral-arm/blacklist
