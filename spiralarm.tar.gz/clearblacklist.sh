#!/usr/bin/env bash
rm -f /var/opt/spiral-arm/blacklist
touch /var/opt/spiral-arm/blacklist
