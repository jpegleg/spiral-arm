#!/usr/bin/env bash
rm -f /opt/spiral-arm/whitelist
touch /opt/spiral-arm/whitelist
