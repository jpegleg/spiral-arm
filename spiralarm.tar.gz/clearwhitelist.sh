#!/usr/bin/env bash
rm -f /var/opt/spiral-arm/whitelist
touch /var/opt/spiral-arm/whitelist
