#!/usr/bin/env bash
kill -9 $(cat /var/opt/spiral-arm/black.pid)
