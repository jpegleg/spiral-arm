#!/usr/bin/env bash
kill -9 $(cat /opt/spiral-arm/black.pid)
