#!/usr/bin/bash
rm -f /var/opt/spiral-arm/whitelist
touch /var/opt/spiral-arm/whitelist
